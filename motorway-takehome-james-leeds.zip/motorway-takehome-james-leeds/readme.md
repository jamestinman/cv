# Motorway Takehome Backend

## Install requirements:
 - docker (https://docs.docker.com/get-docker/)

## Getting started
* To initialize this project, run `docker compose up` from the root of this project. This will build and seed the database. By default the database runs on port `5432` and is also exposed on `5432`, if you want to change this you can update `docker-compose.yml`.
* From the project root run `yarn install` followed by `yarn start-dev`

### Production
Use `yarn start`

### Environment
Requests are by default served via port 3001.
You can change this by updating `.env`

### Usage
Make a get or post API call to `/api/vehicle` with vehicleId{integer} and timestamp{string} e.g.:
`http://localhost:3001/api/vehicle?vehicleId=2&timestamp=2022-09-12%2010:00:00%2b00`

## Testing (jest)
Run `yarn test`

## Musical accompaniment
https://www.youtube.com/watch?v=iukUMRlaBBE
