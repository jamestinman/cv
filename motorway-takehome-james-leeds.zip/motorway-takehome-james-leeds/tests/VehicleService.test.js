const VehicleService = require("../src/services/VehicleService");
const VehicleModel = require("../src/models/VehicleModel");

jest.mock("../src/models/VehicleModel");

test("correct vehicle state is returned", () => {
  VehicleModel.getVehicle.mockResolvedValue({"id":3, "make":"VW", "model":"GOLF", "state":"sold"});
  VehicleModel.getStateAt.mockResolvedValue("quoted");
  return VehicleService.getVehicle(
    {vehicleId:3, timestamp:"2022-09-12 10:00:00+00"}
  ).then(data => expect(data).toEqual({
    "vehicle":{
      "id":3,
      "make":"VW",
      "model":"GOLF",
      "state":"quoted"
    },
    "timestamp":"2022-09-12 10:00:00+00"
  }));
});
