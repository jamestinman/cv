const pgdb = require("../db/pgdb");

// VehicleModel handles data retrieval / validation
class VehicleModel {

  // Get a vehicle
  getVehicle = async (vehicleId) => {
    var db = pgdb.getDb();
    var vehicles = await db.query('SELECT * FROM vehicles WHERE id=$1', [vehicleId]);
    return vehicles.rows[0];
  };

  // Gets the vehicle's state as of a given timestamp
  getStateAt = async (vehicleId, ts) => {
    var db = pgdb.getDb();
    var states = await db.query('SELECT * FROM "stateLogs" WHERE "vehicleId"=$1 AND timestamp<=$2 ORDER BY timestamp DESC', [vehicleId, ts]);
    if (!states.rows || !states.rows[0]) {
      return "prequote";
    }
    return states.rows[0].state;
 }
}

module.exports = new VehicleModel();
