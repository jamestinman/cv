// App entry point for Motorway Tech Challenge
// Node includes
const express = require('express')
const app = express()
const fs = require("fs")

// Bespoke includes
const apiRouter = require("./routes/apiRouter");
const pgdb = require("./db/pgdb");

// Environment
require('dotenv').config()
const port = process.env.PORT;

// ROUTING

//// Status
app.get('/status', (req, res) => {
  res.send({ status: "OK" })
})

//// API calls (handled by apiRouter)
app.use(`/api`, apiRouter);

// Connect to postgres
pgdb.connectToServer(function (err) {
  if (err) {
    console.error(err);
    process.exit();
  }

  // Start the webserver process
  app.listen(port, () => {
    console.log(`Motorway server listening on port ${port}`)
  });
});
