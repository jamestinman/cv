const pgdb = require("../db/pgdb");
const VehicleModel = require("../models/VehicleModel");

// The main VehicleService class
class VehicleService {

  /**
   * Returns vehicle info along with state at given timestamp
   *
   * @param {number} vehicleId
   * @param {string} timestamp
   * @returns {<Object>}
   */
  getVehicle = async (query) => {
    var vehicleId = query.vehicleId || 0;
    var timestamp = query.timestamp || false;
    var ts = new Date(); // Default to now if no timestamp passed
    if (timestamp) {
      // Postgres timestamps require some manipulation for javascript to understand
      timestamp = timestamp.replace("+"," UTC+");
      ts = new Date(timestamp);
    }
    // Fetch the vehicle from id
    var vehicle = await VehicleModel.getVehicle(vehicleId);
    // Override the vehicle's state with the start @ given date
    vehicle.state = await VehicleModel.getStateAt(vehicleId, ts);
    return {vehicle:vehicle, timestamp: query.timestamp}
  }

  status = () => {
    return {rc: 0, msg: "OK"};
  }
}

module.exports = new VehicleService();
