const VehicleService = require("../services/VehicleService");

class ApiController {

  vehicle = async (req, res) => {
    const results = await VehicleService.getVehicle(req.query);
    res.send(results);
  };

}

module.exports = new ApiController();
