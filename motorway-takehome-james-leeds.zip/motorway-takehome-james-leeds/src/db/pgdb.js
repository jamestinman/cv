// Postgresql connection pool management
// Note: Think I read somewhere that you use Sequelize at Motorway
// but opted for a standard postgres connection for simplicity in this task
const { Pool } = require("pg");

let pool;
let client;

module.exports = {

  connectToServer: function (callback) {
    pool = new Pool({
      user: process.env.PG_USER,
      host: process.env.PG_HOST,
      database: process.env.PG_DB,
      password: process.env.PG_PASSWORD,
      port: process.env.PG_PORT,
    });
    pool.connect(function (err, cli) {
      if (err) {
        return callback(err);
      }
      client = cli;
      console.log("Successfully connected to postgres");
      return callback();
    });
  },

  getDb: function () {
    // We only need single queries here, so return the pool to use pool.query
    // May wish to manage our own client connect / release as it scales
    return pool;
  },
};
