// All routes starting with /api/...
const express = require("express");
const router = express.Router();
const ApiController = require("../controllers/ApiController");
const awaitHandlerFactory = require("../middleware/awaitHandlerFactory.middleware");

router.get("/vehicle", awaitHandlerFactory(
  ApiController.vehicle
));

module.exports = router;
